function _mergeNamespaces(n, m) {
  for (var i = 0; i < m.length; i++) {
    const e = m[i];
    if (typeof e !== "string" && !Array.isArray(e)) {
      for (const k in e) {
        if (k !== "default" && !(k in n)) {
          const d = Object.getOwnPropertyDescriptor(e, k);
          if (d) {
            Object.defineProperty(n, k, d.get ? d : {
              enumerable: true,
              get: () => e[k]
            });
          }
        }
      }
    }
  }
  return Object.freeze(Object.defineProperty(n, Symbol.toStringTag, { value: "Module" }));
}
var webApp = {};
Object.defineProperty(webApp, "__esModule", { value: true });
var WebApp = webApp.WebApp = void 0;
if (typeof window !== "object" || window === null) {
  console.error("Error: Telegram Web App is not running in a browser environment, window is not accessible!");
} else if (typeof window.Telegram !== "object" || window.Telegram === null) {
  console.error("Error: Telegram Web App script has not run, see https://core.telegram.org/bots/webapps#initializing-web-apps");
}
WebApp = webApp.WebApp = window.Telegram.WebApp;
var _default = webApp.default = window.Telegram;
const index = /* @__PURE__ */ _mergeNamespaces({
  __proto__: null,
  get WebApp() {
    return WebApp;
  },
  default: _default
}, [webApp]);
export {
  index as i
};
