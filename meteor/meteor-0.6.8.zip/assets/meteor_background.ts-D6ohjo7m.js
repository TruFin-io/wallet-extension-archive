import { b as buffer, E as EnvironmentStateAdapter, n as notNullEmpty, q as queryString, a as nullEmpty, g as getNearApi, c as account_utils, M as MeteorSharedApiMethods, d as EDappActionErrorTag } from "./index-DDmF7Gxt.js";
import { a as SIGN_POPUP_WIDTH, S as SIGN_POPUP_HEIGHT } from "./constants_theme-DBpwduVV.js";
import { E as EMeteorExtensionDirectActionType, a as EExternalActionType, b as EDappActionConnectionStatus, c as EDappActionSource } from "./types_dappConnect-BxVZjSLy.js";
globalThis.Buffer = buffer.Buffer;
const windowsForTabIds = {};
const closeListenersForWindows = {};
chrome.windows.onRemoved.addListener((windowId) => {
  if (closeListenersForWindows[windowId] != null) {
    closeListenersForWindows[windowId]();
    delete closeListenersForWindows[windowId];
  }
});
const connectionIdWindowState = {};
async function ensureWindowOpen(tabId, connectionId, url, pageMeta) {
  let checkWindow;
  let userClosed = false;
  const tabAndConnectionId = `${tabId}`;
  if (connectionIdWindowState[connectionId] == null) {
    connectionIdWindowState[connectionId] = {
      wasFocused: false,
      wasClosed: false
    };
  }
  if (windowsForTabIds[tabAndConnectionId] != null) {
    try {
      checkWindow = await chrome.windows.get(windowsForTabIds[tabAndConnectionId].win.id);
    } catch (e) {
      userClosed = true;
    }
  }
  const handleWindowClosed = () => {
    sendMessageResponse(tabId, {
      uid: connectionId,
      status: EDappActionConnectionStatus.closed_window,
      endTags: [EDappActionErrorTag.INCOMPLETE_ACTION, EDappActionErrorTag.WINDOW_CLOSED],
      tabId
    });
    connectionIdWindowState[connectionId].wasClosed = true;
    delete windowsForTabIds[tabAndConnectionId];
  };
  if (!connectionIdWindowState[connectionId].wasClosed) {
    if (checkWindow == null) {
      if (userClosed) {
        handleWindowClosed();
      } else {
        const openedWindow = await chrome.windows.create({
          url,
          type: "popup",
          height: SIGN_POPUP_HEIGHT + 30,
          width: SIGN_POPUP_WIDTH + 5,
          top: pageMeta.y,
          left: pageMeta.x
        });
        closeListenersForWindows[openedWindow.id] = handleWindowClosed;
        windowsForTabIds[tabAndConnectionId] = { win: openedWindow };
      }
    } else {
      if (!connectionIdWindowState[connectionId].wasFocused) {
        chrome.windows.update(windowsForTabIds[tabAndConnectionId].win.id, {
          focused: true
        });
        connectionIdWindowState[connectionId].wasFocused = true;
      }
    }
  }
  return windowsForTabIds[tabAndConnectionId];
}
function sendMessageResponse(tabId, data) {
  chrome.tabs.query({}, function(tabs) {
    for (const tab of tabs) {
      if (tab.id === tabId) {
        chrome.tabs.sendMessage(tab.id, data);
      }
    }
  });
}
const sessionStorageAdapter = new EnvironmentStateAdapter({
  getString: async (key) => {
    var _a;
    return (_a = await chrome.storage.session.get()) == null ? void 0 : _a[key];
  },
  setString: async (key, value) => await chrome.storage.session.set({ [key]: value })
});
const localStorageAdapter = new EnvironmentStateAdapter({
  getString: async (key) => {
    var _a;
    return (_a = await chrome.storage.local.get()) == null ? void 0 : _a[key];
  },
  setString: async (key, value) => await chrome.storage.local.set({ [key]: value })
});
async function runVerification(inputs) {
  var _a;
  const { message, accountId, network, host } = inputs;
  if (nullEmpty(accountId)) {
    return {
      isGood: false,
      reason: "NO_ACCOUNT_ID"
    };
  }
  const sessionAccounts = await sessionStorageAdapter.getJson("sessionAccounts");
  if (sessionAccounts == null || sessionAccounts[accountId] == null) {
    return {
      isGood: false,
      reason: "NO_SESSION_ACCOUNT"
    };
  }
  const account = sessionAccounts[accountId];
  if (((_a = account.allowVerifyHosts) == null ? void 0 : _a.find((h) => h.host === host)) == null) {
    console.warn("Account was here but didn't have allowed hosts, so need confirmation in app");
    return {
      isGood: false,
      reason: "HOST_NOT_ALLOWED"
    };
  }
  try {
    if (!getNearApi(network).isInitialized) {
      await getNearApi(network).initialize();
    }
    await account_utils.replaceKeystoresWithSessionAccounts({
      [accountId]: account
    });
    const response = await MeteorSharedApiMethods.verifyAccountOwnership({
      accountId,
      network,
      message
    });
    return {
      isGood: true,
      payload: response.verifiedOwner
    };
  } catch (e) {
    console.error(e);
    return {
      isGood: false,
      reason: e == null ? void 0 : e.message
    };
  }
}
const verificationsForUid = {};
async function verifyForUidAndAccount(uid, inputs) {
  if (verificationsForUid[uid] == null) {
    verificationsForUid[uid] = runVerification(inputs);
  }
  return verificationsForUid[uid];
}
function makeAccountId(account) {
  return `ID{${account.id}}NETWORK{${account.network}}`;
}
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  var _a;
  const tabId = ((_a = sender.tab) == null ? void 0 : _a.id) ?? 0;
  if (request && request.action === "wallet_com_direct") {
    if (request.params.actionType === EMeteorExtensionDirectActionType.check_sync_status) {
      const { hash, checkAccounts } = request.params.inputs;
      (async () => {
        const profiles = await localStorageAdapter.getJson("profiles");
        const foundProfile = profiles == null ? void 0 : profiles.find(
          (profile) => notNullEmpty(profile.passwordMatchHash) && profile.passwordMatchHash === hash
        );
        let response;
        if (!foundProfile) {
          response = {
            matched: false,
            accountSync: {
              extMissing: [],
              webMissing: []
            }
          };
        } else {
          const accounts = await localStorageAdapter.getJson("allAccounts");
          if (accounts == null) {
            response = {
              matched: true,
              accountSync: {
                extMissing: checkAccounts,
                webMissing: []
              }
            };
          } else {
            const incomingWebIds = checkAccounts.map(makeAccountId);
            const intersectionIds = [];
            const webMissing = [];
            for (const extAccount of accounts) {
              if (extAccount.profileId === foundProfile.id) {
                const minimalId = makeAccountId(extAccount);
                if (incomingWebIds.includes(minimalId)) {
                  intersectionIds.push(minimalId);
                } else {
                  webMissing.push({
                    id: extAccount.id,
                    network: extAccount.network,
                    label: extAccount.label
                  });
                }
              }
            }
            const extMissing = checkAccounts.filter(
              (acc) => !intersectionIds.includes(makeAccountId(acc))
            );
            response = {
              matched: true,
              accountSync: {
                extMissing,
                webMissing
              }
            };
          }
        }
        sendResponse(response);
      })();
    }
    if (request.params.actionType === EMeteorExtensionDirectActionType.sync_accounts) {
      const { passwordHash, accounts } = request.params.inputs;
      sendResponse({
        accounts: [],
        success: false
      });
    }
    if (request.params.actionType === EMeteorExtensionDirectActionType.open_page) {
      const { path, queryParams, hash } = request.params.inputs;
      (async () => {
        let urlString = `ext_index.html?route=${path}&${queryString.stringify(queryParams)}`;
        if (notNullEmpty(hash)) {
          urlString = `${urlString}#${hash}`;
        }
        const window = await chrome.tabs.create({
          url: chrome.runtime.getURL(urlString)
        });
        if (window.id != null) {
          sendResponse({
            opened: true
          });
        } else {
          sendResponse({
            opened: false
          });
        }
      })();
    }
    return true;
  }
  if (request && request.action === "wallet_com_response") {
    if (request.params.tabId == null) {
      console.warn("Got message from client without a tabId set");
    } else {
      sendMessageResponse(request.params.tabId, request.params);
    }
  }
  if (request && request.action === "wallet_com") {
    (async () => {
      var _a2, _b;
      if (request.params.actionType === EExternalActionType.verify_owner) {
        const accountId = (_a2 = request.params.inputs) == null ? void 0 : _a2.accountId;
        const message = (_b = request.params.inputs) == null ? void 0 : _b.message;
        const hostUrl = new URL(request.pageMeta.pageUri);
        const response = await verifyForUidAndAccount(request.params.uid, {
          host: hostUrl.hostname,
          accountId,
          message,
          network: request.params.network
        });
        if (response.isGood) {
          sendMessageResponse(tabId, {
            ...request.params,
            status: EDappActionConnectionStatus.closed_success,
            payload: response.payload
          });
          return;
        }
      }
      const openedWindow = await ensureWindowOpen(
        tabId,
        request.params.uid,
        chrome.runtime.getURL(
          `ext_index.html?route=/connect/${request.params.network}/${request.params.actionType}&source=${EDappActionSource.extension_injected}&pageUri=${request.pageMeta.pageUri}&connectionUid=${request.params.uid}`
        ),
        request.pageMeta
      );
      if (openedWindow != null) {
        request.action = "wallet_com_client";
        request.params.tabId = tabId;
        chrome.runtime.sendMessage(chrome.runtime.id, request, () => {
          return true;
        });
      }
    })();
  }
});
