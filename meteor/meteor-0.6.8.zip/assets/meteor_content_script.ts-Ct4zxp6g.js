import { S as SIGN_POPUP_HEIGHT, a as SIGN_POPUP_WIDTH } from "./constants_theme-DBpwduVV.js";
const injectSrc = "/assets/meteor_inpage.ts-Dw9Lq1NC.js";
const script = document.createElement("script");
script.src = chrome.runtime.getURL(injectSrc);
script.type = "module";
document.head.prepend(script);
window.addEventListener("meteor_wallet_com", (evt) => {
  const w = SIGN_POPUP_WIDTH;
  const h = SIGN_POPUP_HEIGHT;
  const y = Math.floor(window.top.outerHeight / 2 + window.top.screenY - h / 2);
  const x = Math.floor(window.top.outerWidth / 2 + window.top.screenX - w / 2);
  chrome.runtime.sendMessage({
    action: "wallet_com",
    params: evt.detail,
    pageMeta: {
      x,
      y,
      w,
      h,
      pageUri: window.location.href
    }
  });
});
function sendMessagePromise(data) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(data, (response) => {
      resolve(response);
    });
  });
}
window.addEventListener("meteor_wallet_com_direct", async (evt) => {
  const detail = evt.detail;
  const response = await sendMessagePromise({
    action: "wallet_com_direct",
    params: detail.data
  });
  const event = new CustomEvent("meteor_wallet_com_direct_response", {
    detail: {
      uid: detail.uid,
      output: response
    }
  });
  window.dispatchEvent(event);
});
chrome.runtime.onMessage.addListener(function(request, sender) {
  const event = new CustomEvent("meteor_wallet_com_response", {
    detail: request
  });
  window.dispatchEvent(event);
});
