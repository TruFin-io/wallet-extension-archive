import { e as EMeteorInjectedFeature, n as nanoid } from "./types_dappConnect-BxVZjSLy.js";
const listeners = [];
window.addEventListener("meteor_wallet_com_response", (event) => {
  for (const listener of listeners) {
    listener(event.detail);
  }
});
const promisesForDirect = {};
window.addEventListener("meteor_wallet_com_direct_response", (event) => {
  const detail = event.detail;
  const uid = detail.uid;
  if (uid != null && promisesForDirect[uid] != null) {
    promisesForDirect[uid].resolve(detail.output);
  }
});
window.meteorCom = {
  addMessageDataListener: (listener) => {
    listeners.push(listener);
  },
  sendMessageData: (data) => {
    const event = new CustomEvent("meteor_wallet_com", { detail: data });
    window.dispatchEvent(event);
  },
  directAction: async (actionData) => {
    const uid = nanoid(6);
    const promise = new Promise((actualResolve, actualReject) => {
      promisesForDirect[uid] = {
        isResolved: false,
        resolve: (value) => {
          promisesForDirect[uid].isResolved = true;
          actualResolve(value);
        },
        reject: () => {
          if (!promisesForDirect[uid].isResolved) {
            actualReject();
          }
        }
      };
    });
    const event = new CustomEvent("meteor_wallet_com_direct", {
      detail: { uid, data: actionData }
    });
    window.dispatchEvent(event);
    return promise;
  },
  features: [
    EMeteorInjectedFeature.batch_import,
    EMeteorInjectedFeature.sync_check,
    EMeteorInjectedFeature.open_page
  ]
};
const meteor_inpage = {};
export {
  meteor_inpage as default
};
