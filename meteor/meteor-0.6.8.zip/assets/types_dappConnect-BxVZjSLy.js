const urlAlphabet = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict";
let nanoid = (size = 21) => {
  let id = "";
  let bytes = crypto.getRandomValues(new Uint8Array(size |= 0));
  while (size--) {
    id += urlAlphabet[bytes[size] & 63];
  }
  return id;
};
var EExternalActionType = /* @__PURE__ */ ((EExternalActionType2) => {
  EExternalActionType2["login"] = "login";
  EExternalActionType2["sign"] = "sign";
  EExternalActionType2["logout"] = "logout";
  EExternalActionType2["verify_owner"] = "verify_owner";
  EExternalActionType2["keypom_claim"] = "keypom_claim";
  EExternalActionType2["sign_message"] = "sign_message";
  return EExternalActionType2;
})(EExternalActionType || {});
var EMeteorWalletSignInType = /* @__PURE__ */ ((EMeteorWalletSignInType2) => {
  EMeteorWalletSignInType2["ALL_METHODS"] = "ALL_METHODS";
  EMeteorWalletSignInType2["SELECTED_METHODS"] = "SELECTED_METHODS";
  EMeteorWalletSignInType2["FULL_ACCESS"] = "FULL_ACCESS";
  return EMeteorWalletSignInType2;
})(EMeteorWalletSignInType || {});
var EWalletExternalActionStatus = /* @__PURE__ */ ((EWalletExternalActionStatus2) => {
  EWalletExternalActionStatus2["UNCONFIRMED"] = "UNCONFIRMED";
  EWalletExternalActionStatus2["PENDING"] = "PENDING";
  EWalletExternalActionStatus2["SUCCESS"] = "SUCCESS";
  EWalletExternalActionStatus2["FAILURE"] = "FAILURE";
  return EWalletExternalActionStatus2;
})(EWalletExternalActionStatus || {});
var EMeteorExtensionDirectActionType = /* @__PURE__ */ ((EMeteorExtensionDirectActionType2) => {
  EMeteorExtensionDirectActionType2["check_sync_status"] = "check_sync_status";
  EMeteorExtensionDirectActionType2["sync_accounts"] = "sync_accounts";
  EMeteorExtensionDirectActionType2["open_page"] = "open_page";
  return EMeteorExtensionDirectActionType2;
})(EMeteorExtensionDirectActionType || {});
var EMeteorInjectedFeature = /* @__PURE__ */ ((EMeteorInjectedFeature2) => {
  EMeteorInjectedFeature2["open_page"] = "open_page";
  EMeteorInjectedFeature2["batch_import"] = "batch_import";
  EMeteorInjectedFeature2["sync_check"] = "sync_check";
  EMeteorInjectedFeature2["account_sync"] = "account_sync";
  return EMeteorInjectedFeature2;
})(EMeteorInjectedFeature || {});
var EDappActionSource = /* @__PURE__ */ ((EDappActionSource2) => {
  EDappActionSource2["website_callback"] = "wcb";
  EDappActionSource2["website_post_message"] = "wpm";
  EDappActionSource2["website_visit"] = "wv";
  EDappActionSource2["extension_injected"] = "ext";
  return EDappActionSource2;
})(EDappActionSource || {});
var EDappActionConnectionStatus = /* @__PURE__ */ ((EDappActionConnectionStatus2) => {
  EDappActionConnectionStatus2["initializing"] = "initializing";
  EDappActionConnectionStatus2["connected"] = "connected";
  EDappActionConnectionStatus2["attempting_reconnect"] = "attempting_reconnect";
  EDappActionConnectionStatus2["disconnected"] = "disconnected";
  EDappActionConnectionStatus2["closed_success"] = "closed_success";
  EDappActionConnectionStatus2["closed_fail"] = "closed_fail";
  EDappActionConnectionStatus2["closed_window"] = "closed_window";
  return EDappActionConnectionStatus2;
})(EDappActionConnectionStatus || {});
export {
  EMeteorExtensionDirectActionType as E,
  EExternalActionType as a,
  EDappActionConnectionStatus as b,
  EDappActionSource as c,
  EMeteorWalletSignInType as d,
  EMeteorInjectedFeature as e,
  EWalletExternalActionStatus as f,
  nanoid as n
};
