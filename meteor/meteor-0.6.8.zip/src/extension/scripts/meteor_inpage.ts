import {
  EMeteorInjectedFeature,
  IMeteorComInjectedObject,
  TClientPostMessageResponse,
  TMeteorComListener,
} from "@meteorwallet/common/modules_feature/dapp_connect/types_dappConnect";
import { nanoid } from "nanoid";

declare global {
  interface Window {
    meteorCom?: IMeteorComInjectedObject;
  }
}

// console.log("Injected wallet sdk content script in page!");

const listeners: TMeteorComListener<TClientPostMessageResponse>[] = [];

window.addEventListener("meteor_wallet_com_response", (event) => {
  // console.log("[RESP] In Page Script", (event as any).detail);
  for (const listener of listeners) {
    listener((event as any).detail as TClientPostMessageResponse);
  }
});

const promisesForDirect: {
  [uid: string]: {
    isResolved: boolean;
    resolve: (value: unknown) => void;
    reject: () => void;
  };
} = {};

window.addEventListener("meteor_wallet_com_direct_response", (event) => {
  console.log("[DIRECT RESP] In Page Script", (event as any).detail);
  const detail = (event as any).detail;
  const uid = detail.uid;

  if (uid != null && promisesForDirect[uid] != null) {
    promisesForDirect[uid].resolve(detail.output);
  }
});

window.meteorCom = {
  addMessageDataListener: (listener: TMeteorComListener<TClientPostMessageResponse>) => {
    listeners.push(listener);
  },
  sendMessageData: (data) => {
    // console.log("[OUTGOING] In Page Script", data);
    const event = new CustomEvent("meteor_wallet_com", { detail: data });
    window.dispatchEvent(event);
  },
  directAction: async (actionData): Promise<any> => {
    console.log("[DIRECT OUTGOING] In Page Script", actionData);
    const uid = nanoid(6);

    const promise = new Promise((actualResolve, actualReject) => {
      promisesForDirect[uid] = {
        isResolved: false,
        resolve: (value) => {
          promisesForDirect[uid].isResolved = true;
          actualResolve(value);
        },
        reject: () => {
          if (!promisesForDirect[uid].isResolved) {
            actualReject();
          }
        },
      };
    });

    const event = new CustomEvent("meteor_wallet_com_direct", {
      detail: { uid, data: actionData },
    });
    window.dispatchEvent(event);

    return promise;
  },
  features: [
    EMeteorInjectedFeature.batch_import,
    EMeteorInjectedFeature.sync_check,
    EMeteorInjectedFeature.open_page,
  ],
};

export default {};
