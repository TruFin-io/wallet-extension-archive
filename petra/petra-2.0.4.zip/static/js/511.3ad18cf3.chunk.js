"use strict";(self.webpackChunk_petra_extension=self.webpackChunk_petra_extension||[]).push([[511],{48511:e=>{e.exports=JSON.parse('{"UdOBQs":[{"type":0,"value":"\u6b61\u8fce\u56de\u4f86"}]}')}}]);
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="ae0d7f1d-de29-5438-9252-71ce42fd490c")}catch(e){}}();
//# debugId=ae0d7f1d-de29-5438-9252-71ce42fd490c
