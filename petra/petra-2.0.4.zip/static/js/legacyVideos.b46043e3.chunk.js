"use strict";
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e1e42ba2-1fd9-5c55-beed-c6b398be42fb")}catch(e){}}();
(self.webpackChunk_petra_extension=self.webpackChunk_petra_extension||[]).push([[694],{35511:(e,n,t)=>{t.r(n),t.d(n,{loadLegacyVideoPlugins:()=>i});var r=t(78210);function i(e){return(0,r.__awaiter)(this,void 0,void 0,(function(){var n;return(0,r.__generator)(this,(function(r){switch(r.label){case 0:return[4,t.e(912).then(t.t.bind(t,71912,23))];case 1:return n=r.sent(),e._plugins=n,[2]}}))}))}}}]);
//# sourceMappingURL=legacyVideos.b46043e3.chunk.js.map
//# debugId=e1e42ba2-1fd9-5c55-beed-c6b398be42fb
